<?php
require_once __DIR__ . '/config.php';

function db() {
  static $pdo = null;
  if ($pdo) return $pdo;
  $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
  ]);
  return $pdo;
}

function json_input() {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function respond($data, $code = 200) {
  http_response_code($code);
  header('Content-Type: application/json');
  echo json_encode($data);
  exit;
}

function uuidv4() {
  $d = random_bytes(16);
  $d[6] = chr(ord($d[6]) & 0x0f | 0x40);
  $d[8] = chr(ord($d[8]) & 0x3f | 0x80);
  $hex = bin2hex($d);
  return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20, 12);
}

// The quotation token is a SEPARATE identifier from the row id and from quote_no.
// It is always generated here on the server (never accepted from the client) and is
// what a proposal link is opened with: shubh-solar-quotation.html?token=<this>.
// The DB has a UNIQUE constraint on quote_token; this loop is the extremely-unlikely
// collision fallback the schema comment promises, not the primary uniqueness guarantee.
function generate_quote_token($pdo) {
  $check = $pdo->prepare('SELECT 1 FROM quotations WHERE quote_token = ?');
  for ($attempt = 0; $attempt < 5; $attempt++) {
    $token = bin2hex(random_bytes(16)); // 32 hex chars, matches CHAR(32)
    $check->execute([$token]);
    if (!$check->fetch()) return $token;
  }
  // Astronomically unlikely to ever reach here (2^128 space); fail loudly rather than
  // silently risk a duplicate.
  respond(['success' => false, 'error' => 'Could not generate a unique quotation token, please retry.'], 500);
}

// Same-origin only; adjust if the frontend is served from a different domain.
header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? '*'));
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
