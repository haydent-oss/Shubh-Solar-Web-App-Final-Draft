<?php
require_once __DIR__ . '/db.php';

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

function settings_to_json($s, $co) {
  return [
    'rates' => json_decode($s['package_rates'], true),
    'gstPercent' => $s['gst_percent'], 'tariff' => $s['tariff'], 'unitsPerKw' => $s['units_per_kw'],
    'emiRate' => $s['emi_rate'], 'subsidyCap' => $s['subsidy_cap'],
    'gstin' => $co['gstin'], 'serviceNumber' => $co['service_number'],
    'bankName' => $co['bank_name'], 'accountNo' => $co['account_no']
  ];
}

if ($method === 'GET') {
  $s = $pdo->prepare('SELECT * FROM settings WHERE company_id = ?');
  $s->execute([COMPANY_ID]);
  $s = $s->fetch();
  $co = $pdo->prepare('SELECT * FROM companies WHERE id = ?');
  $co->execute([COMPANY_ID]);
  $co = $co->fetch();
  if (!$s || !$co) respond(['success' => false, 'error' => 'Settings not found.'], 404);
  respond(['success' => true, 'data' => settings_to_json($s, $co)]);
}

if ($method === 'PATCH') {
  $body = json_input();

  // --- settings table (presets: rates, gst, tariff, ...) ---
  $fields = []; $vals = [];
  foreach (['gstPercent' => 'gst_percent', 'tariff' => 'tariff', 'unitsPerKw' => 'units_per_kw', 'emiRate' => 'emi_rate', 'subsidyCap' => 'subsidy_cap'] as $jsKey => $col) {
    if (isset($body[$jsKey])) {
      if (!is_numeric($body[$jsKey]) || (float)$body[$jsKey] < 0) respond(['success' => false, 'error' => "Invalid value for $jsKey."], 400);
      $fields[] = "$col = ?"; $vals[] = $body[$jsKey];
    }
  }
  if (isset($body['rates'])) {
    if (!is_array($body['rates'])) respond(['success' => false, 'error' => 'Invalid rates.'], 400);
    foreach ($body['rates'] as $rate) {
      if (!is_numeric($rate) || (float)$rate < 0) respond(['success' => false, 'error' => 'Invalid rate value.'], 400);
    }
    $fields[] = 'package_rates = ?'; $vals[] = json_encode($body['rates']);
  }
  if ($fields) {
    $vals[] = COMPANY_ID;
    $pdo->prepare('UPDATE settings SET ' . implode(', ', $fields) . ' WHERE company_id = ?')->execute($vals);
  }

  // --- companies table (company details shown on every proposal) ---
  $coFields = []; $coVals = [];
  foreach (['gstin' => 'gstin', 'serviceNumber' => 'service_number', 'bankName' => 'bank_name', 'accountNo' => 'account_no'] as $jsKey => $col) {
    if (isset($body[$jsKey])) {
      $val = trim((string)$body[$jsKey]);
      if ($val === '') respond(['success' => false, 'error' => "$jsKey cannot be empty."], 400);
      $coFields[] = "$col = ?"; $coVals[] = $val;
    }
  }
  if ($coFields) {
    $coVals[] = COMPANY_ID;
    $pdo->prepare('UPDATE companies SET ' . implode(', ', $coFields) . ' WHERE id = ?')->execute($coVals);
  }

  $s = $pdo->prepare('SELECT * FROM settings WHERE company_id = ?');
  $s->execute([COMPANY_ID]);
  $s = $s->fetch();
  $co = $pdo->prepare('SELECT * FROM companies WHERE id = ?');
  $co->execute([COMPANY_ID]);
  $co = $co->fetch();
  respond(['success' => true, 'data' => settings_to_json($s, $co)]);
}

respond(['success' => false, 'error' => 'Method not allowed'], 405);
