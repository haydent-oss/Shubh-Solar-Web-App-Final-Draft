<?php
// Fill these in with your Hostinger MySQL credentials (hPanel > Databases).
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');

// Matches the seed row in database_mysql.sql — change if you insert a different company.
define('COMPANY_ID', 'a0000000-0000-0000-0000-000000000001');
