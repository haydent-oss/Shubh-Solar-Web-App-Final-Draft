<?php
require_once __DIR__ . '/db.php';

function row_to_quote($r) {
  return [
    'id' => $r['id'],
    'token' => $r['quote_token'],
    'quoteNo' => $r['quote_no'],
    'name' => $r['customer_name'],
    'place' => $r['address'] ?: '',
    'phone' => $r['phone'] ?: '',
    'kw' => (float)$r['kw'],
    'net' => (float)$r['net_cost'],
    'monthly' => (float)$r['monthly_savings'],
    'status' => $r['status'],
    'date' => date('d M', strtotime($r['created_at'])),
    'synced' => true,
    'snapshot' => [
      'form' => [
        'name' => $r['customer_name'], 'address' => $r['address'], 'phone' => $r['phone'],
        'consumerNo' => $r['consumer_no'], 'category' => $r['category'], 'bill' => (string)$r['avg_monthly_bill'],
        'kw' => (float)$r['kw'], 'panel' => $r['panel_brand'], 'inverter' => $r['inverter_brand'],
        'emiYears' => (int)$r['emi_years_selected'], 'validDays' => (string)$r['valid_days'], 'pm' => $r['pm_name']
      ],
      'calc' => [
        'kw' => (float)$r['kw'], 'rate' => (float)$r['rate'], 'base' => (float)$r['base_cost'],
        'totalPayable' => (float)$r['total_payable'], 'subsidy' => (float)$r['subsidy'], 'netCost' => (float)$r['net_cost'],
        'residential' => $r['category'] === 'Residential',
        'annualUnits' => (float)$r['annual_units'], 'annualSavings' => (float)$r['annual_savings'],
        'monthlySavings' => (float)$r['monthly_savings'], 'payback' => (float)$r['payback_years'], 'lifetime' => (float)$r['lifetime_savings'],
        'emi3' => (float)$r['emi_3yr'], 'emi5' => (float)$r['emi_5yr'], 'emi7' => (float)$r['emi_7yr'], 'emi10' => (float)$r['emi_10yr'],
        'panelQty' => (int)$r['panel_qty'], 'panelWattage' => (int)$r['panel_wattage'], 'roofArea' => (int)$r['roof_area_sqft'],
        'validUntil' => date('d M Y', strtotime($r['valid_until'])), 'quoteNo' => $r['quote_no']
      ]
    ]
  ];
}

// ---- server-side validation helpers (never trust the frontend) ----
function require_fields($f, $c, $body, &$err) {
  if (!isset($f['name']) || trim((string)$f['name']) === '') { $err = 'Customer name is required.'; return false; }
  if (!isset($c['kw']) || !is_numeric($c['kw']) || (float)$c['kw'] <= 0) { $err = 'A valid system size (kW) is required.'; return false; }
  if (!isset($f['bill']) || !is_numeric(str_replace(',', '', (string)$f['bill'])) || (float)str_replace(',', '', (string)$f['bill']) < 0) { $err = 'A valid monthly bill is required.'; return false; }
  if (isset($f['category']) && !in_array($f['category'], ['Residential', 'Commercial'], true)) { $err = 'Invalid category.'; return false; }
  if (isset($body['status']) && !in_array($body['status'], ['Draft', 'Sent', 'Won', 'Lost'], true)) { $err = 'Invalid status.'; return false; }
  foreach (['rate', 'base', 'totalPayable', 'subsidy', 'netCost', 'annualUnits', 'annualSavings', 'monthlySavings'] as $k) {
    if (isset($c[$k]) && (!is_numeric($c[$k]) || (float)$c[$k] < 0)) { $err = "Invalid value for $k."; return false; }
  }
  return true;
}

// validDays comes straight from the client and feeds strtotime()/date() below — clamp it
// to a sane integer range so malformed input (e.g. a non-numeric string) can never make
// strtotime() return false and get passed into date(), which is a hard error on PHP 8.1+.
function sanitize_valid_days($v) {
  $n = (int)$v;
  if ($n < 1) return 15;
  if ($n > 365) return 365;
  return $n;
}

function bind_quote_values($id, $token, $quoteNo, $status, $f, $c) {
  $validDays = sanitize_valid_days($f['validDays'] ?? 15);
  return [
    $id, $token, COMPANY_ID, $quoteNo, $status,
    trim((string)($f['name'] ?? 'Untitled customer')), $f['address'] ?? '', $f['phone'] ?? '', $f['consumerNo'] ?? '', $f['category'] ?? 'Residential',
    $f['bill'] ?? 0, $c['kw'] ?? 0, $f['panel'] ?? '', $f['inverter'] ?? '', $f['emiYears'] ?? 5, $validDays, $f['pm'] ?? '',
    $c['rate'] ?? 0, $c['base'] ?? 0, ($c['totalPayable'] ?? 0) - ($c['base'] ?? 0), $c['totalPayable'] ?? 0, $c['subsidy'] ?? 0, $c['netCost'] ?? 0, $c['annualUnits'] ?? 0, $c['annualSavings'] ?? 0,
    $c['monthlySavings'] ?? 0, $c['payback'] ?? 0, $c['lifetime'] ?? 0, $c['emi3'] ?? 0, $c['emi5'] ?? 0, $c['emi7'] ?? 0, $c['emi10'] ?? 0,
    $c['panelQty'] ?? 0, $c['panelWattage'] ?? 550, $c['roofArea'] ?? 0, date('Y-m-d', strtotime("+$validDays days"))
  ];
}

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

// ---- GET: full list, OR a single quotation by token (used by the proposal page) ----
if ($method === 'GET') {
  if (isset($_GET['token'])) {
    $stmt = $pdo->prepare('SELECT * FROM quotations WHERE quote_token = ? AND company_id = ?');
    $stmt->execute([$_GET['token'], COMPANY_ID]);
    $row = $stmt->fetch();
    if (!$row) respond(['success' => false, 'error' => 'Quotation not found.'], 404);
    respond(['success' => true, 'data' => row_to_quote($row)]);
  }
  $stmt = $pdo->prepare('SELECT * FROM quotations WHERE company_id = ? ORDER BY created_at DESC');
  $stmt->execute([COMPANY_ID]);
  respond(['success' => true, 'data' => array_map('row_to_quote', $stmt->fetchAll())]);
}

// ---- POST: create a NEW quotation. Token and quote_no are ALWAYS assigned here,
// never accepted from the client (Issue 1 / Issue 2). ----
if ($method === 'POST') {
  $body = json_input();
  $f = $body['form'] ?? []; $c = $body['calc'] ?? [];
  $err = null;
  if (!require_fields($f, $c, $body, $err)) respond(['success' => false, 'error' => $err], 400);
  try {
    $pdo->beginTransaction();
    $seqStmt = $pdo->prepare('UPDATE companies SET quote_seq = quote_seq + 1 WHERE id = ?');
    $seqStmt->execute([COMPANY_ID]);
    $seqRow = $pdo->prepare('SELECT quote_seq, fy_label FROM companies WHERE id = ?');
    $seqRow->execute([COMPANY_ID]);
    $seq = $seqRow->fetch();
    $quoteNo = 'SS/' . $seq['fy_label'] . '/' . str_pad($seq['quote_seq'], 3, '0', STR_PAD_LEFT);
    $id = uuidv4();
    $token = generate_quote_token($pdo);

    $stmt = $pdo->prepare('INSERT INTO quotations (
      id, quote_token, company_id, quote_no, status, customer_name, address, phone, consumer_no, category,
      avg_monthly_bill, kw, panel_brand, inverter_brand, emi_years_selected, valid_days, pm_name,
      rate, base_cost, gst_amount, total_payable, subsidy, net_cost, annual_units, annual_savings,
      monthly_savings, payback_years, lifetime_savings, emi_3yr, emi_5yr, emi_7yr, emi_10yr,
      panel_qty, panel_wattage, roof_area_sqft, valid_until
    ) VALUES (?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?)');
    $stmt->execute(bind_quote_values($id, $token, $quoteNo, $body['status'] ?? 'Draft', $f, $c));
    $pdo->commit();
  } catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    respond(['success' => false, 'error' => 'Could not save the quotation. Please retry.'], 500);
  }

  $row = $pdo->prepare('SELECT * FROM quotations WHERE id = ?');
  $row->execute([$id]);
  respond(['success' => true, 'data' => row_to_quote($row->fetch())], 201);
}

// ---- PUT: EDIT an existing quotation. id, quote_token and quote_no are preserved —
// editing must never mint a new token or a new number (Issue 7). ----
if ($method === 'PUT') {
  $id = $_GET['id'] ?? null;
  if (!$id) respond(['success' => false, 'error' => 'Missing id.'], 400);
  $body = json_input();
  $f = $body['form'] ?? []; $c = $body['calc'] ?? [];
  $err = null;
  if (!require_fields($f, $c, $body, $err)) respond(['success' => false, 'error' => $err], 400);

  $existing = $pdo->prepare('SELECT id, quote_token, quote_no FROM quotations WHERE id = ? AND company_id = ?');
  $existing->execute([$id, COMPANY_ID]);
  $current = $existing->fetch();
  if (!$current) respond(['success' => false, 'error' => 'Quotation not found.'], 404);

  $validDays = sanitize_valid_days($f['validDays'] ?? 15);
  try {
    $stmt = $pdo->prepare('UPDATE quotations SET
      status = ?, customer_name = ?, address = ?, phone = ?, consumer_no = ?, category = ?,
      avg_monthly_bill = ?, kw = ?, panel_brand = ?, inverter_brand = ?, emi_years_selected = ?, valid_days = ?, pm_name = ?,
      rate = ?, base_cost = ?, gst_amount = ?, total_payable = ?, subsidy = ?, net_cost = ?, annual_units = ?, annual_savings = ?,
      monthly_savings = ?, payback_years = ?, lifetime_savings = ?, emi_3yr = ?, emi_5yr = ?, emi_7yr = ?, emi_10yr = ?,
      panel_qty = ?, panel_wattage = ?, roof_area_sqft = ?, valid_until = ?
      WHERE id = ? AND company_id = ?');
    $stmt->execute([
      $body['status'] ?? 'Draft', trim((string)($f['name'] ?? 'Untitled customer')), $f['address'] ?? '', $f['phone'] ?? '', $f['consumerNo'] ?? '', $f['category'] ?? 'Residential',
      $f['bill'] ?? 0, $c['kw'] ?? 0, $f['panel'] ?? '', $f['inverter'] ?? '', $f['emiYears'] ?? 5, $validDays, $f['pm'] ?? '',
      $c['rate'] ?? 0, $c['base'] ?? 0, ($c['totalPayable'] ?? 0) - ($c['base'] ?? 0), $c['totalPayable'] ?? 0, $c['subsidy'] ?? 0, $c['netCost'] ?? 0, $c['annualUnits'] ?? 0, $c['annualSavings'] ?? 0,
      $c['monthlySavings'] ?? 0, $c['payback'] ?? 0, $c['lifetime'] ?? 0, $c['emi3'] ?? 0, $c['emi5'] ?? 0, $c['emi7'] ?? 0, $c['emi10'] ?? 0,
      $c['panelQty'] ?? 0, $c['panelWattage'] ?? 550, $c['roofArea'] ?? 0, date('Y-m-d', strtotime("+$validDays days")),
      $id, COMPANY_ID
    ]);
  } catch (Exception $e) {
    respond(['success' => false, 'error' => 'Could not save the changes. Please retry.'], 500);
  }

  $row = $pdo->prepare('SELECT * FROM quotations WHERE id = ?');
  $row->execute([$id]);
  respond(['success' => true, 'data' => row_to_quote($row->fetch())]);
}

// ---- PATCH: status-only update (kept for the existing quick status chips) ----
if ($method === 'PATCH') {
  $id = $_GET['id'] ?? null;
  if (!$id) respond(['success' => false, 'error' => 'Missing id.'], 400);
  $body = json_input();
  if (!isset($body['status']) || !in_array($body['status'], ['Draft', 'Sent', 'Won', 'Lost'], true)) {
    respond(['success' => false, 'error' => 'Missing or invalid status.'], 400);
  }
  $stmt = $pdo->prepare('UPDATE quotations SET status = ? WHERE id = ? AND company_id = ?');
  $stmt->execute([$body['status'], $id, COMPANY_ID]);
  $row = $pdo->prepare('SELECT * FROM quotations WHERE id = ? AND company_id = ?');
  $row->execute([$id, COMPANY_ID]);
  $found = $row->fetch();
  if (!$found) respond(['success' => false, 'error' => 'Quotation not found.'], 404);
  respond(['success' => true, 'data' => row_to_quote($found)]);
}

// ---- DELETE: remove a quotation, scoped to this company ----
if ($method === 'DELETE') {
  $id = $_GET['id'] ?? null;
  if (!$id) respond(['success' => false, 'error' => 'Missing id.'], 400);
  $check = $pdo->prepare('SELECT id FROM quotations WHERE id = ? AND company_id = ?');
  $check->execute([$id, COMPANY_ID]);
  if (!$check->fetch()) respond(['success' => false, 'error' => 'Quotation not found.'], 404);
  $stmt = $pdo->prepare('DELETE FROM quotations WHERE id = ? AND company_id = ?');
  $stmt->execute([$id, COMPANY_ID]);
  respond(['success' => true, 'data' => ['id' => $id, 'deleted' => true]]);
}

respond(['success' => false, 'error' => 'Method not allowed'], 405);
