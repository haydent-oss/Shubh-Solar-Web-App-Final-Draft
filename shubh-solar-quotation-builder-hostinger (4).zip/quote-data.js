// Shared quotation data: turns an app payload into the proposal's [[TOKEN]] values.
// Loaded as a plain global script by both the app and the proposal.
(function () {
  var COMPANY = {
    PHONE: "98271 44120",
    EMAIL: "shubhsolar.pendra@gmail.com",
    WEBSITE: "www.shubhsolar.in",
    GSTIN: "22ABCDE1234F1Z5",
    SERVICE_NUMBER: "98271 00000",
    RESPONSE_HOURS: "48",
    PENDRA_ADDRESS: "Main Road, near Bus Stand, Pendra, Dist. GPM 495117",
    PENDRA_PHONE: "98271 44120",
    BILASPUR_ADDRESS: "Shop 12, Vyapar Vihar Road, Bilaspur 495001",
    BILASPUR_PHONE: "94255 09813",
    BANK_NAME: "State Bank of India",
    BANK_BRANCH: "Pendra Branch",
    ACCOUNT_NO: "3842 7715 902",
    IFSC: "SBIN0004821",
    BANK_PARTNER: "SBI Surya Ghar / Union Bank rooftop loan",
    // No real Instagram/Facebook profile URLs have been provided anywhere in this
    // project — left blank rather than invented. The proposal page hides those two
    // footer buttons when the value is empty; fill these in with real links to show them.
    INSTAGRAM_URL: "",
    FACEBOOK_URL: "",
    YEARS: "8",
    INSTALLS: "310+",
    KW_TOTAL: "1,240",
    DISTRICTS: "4",
    ADV_PCT: "30",
    DEL_PCT: "50",
    COM_PCT: "20",
    CABLE_LIMIT: "30",
    PM_NAME: "Rohit Sahu",
    PM_PHONE: "97551 20834",
    CASE1_TYPE: "RESIDENTIAL",
    CASE1_LOCATION: "Pendra Road",
    CASE1_SIZE: "3",
    CASE1_DATE: "Mar 2026",
    CASE1_BEFORE: "3,400",
    CASE1_AFTER: "180",
    CASE2_TYPE: "SHOP",
    CASE2_LOCATION: "Bilaspur, Sarkanda",
    CASE2_SIZE: "10",
    CASE2_DATE: "Jan 2026",
    CASE2_BEFORE: "11,600",
    CASE2_AFTER: "740",
    CASE3_TYPE: "RESIDENTIAL",
    CASE3_LOCATION: "Marwahi",
    CASE3_SIZE: "5",
    CASE3_DATE: "Nov 2025",
    CASE3_BEFORE: "5,800",
    CASE3_AFTER: "260",
    TESTIMONIAL1_HI: "बिल अब लगभग शून्य है। टीम ने जो कहा, वही किया।",
    TESTIMONIAL1_NAME: "श्री दिनेश कुमार",
    TESTIMONIAL1_PLACE: "Pendra Road",
    TESTIMONIAL1_SIZE: "3",
    TESTIMONIAL2_HI: "सब्सिडी का पूरा काम शुभ सोलर ने किया, पैसा खाते में आ गया।",
    TESTIMONIAL2_NAME: "सुनीता देवी केशरवानी",
    TESTIMONIAL2_PLACE: "Ratanpur",
    TESTIMONIAL2_SIZE: "5"
  };

  function inr(n) { return Math.round(Number(n) || 0).toLocaleString("en-IN"); }
  function dmy(d) {
    return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  }

  // payload = { form, settings, calc } written by the app; falsy = demo values
  var DEMO = {
    form: {
      name: "श्री रामकुमार जायसवाल",
      address: "वार्ड 4, पेंड्रा रोड, जिला गौरेला-पेंड्रा-मरवाही, छत्तीसगढ़ 495117",
      phone: "98271 44120", category: "Residential", bill: "3200", kw: 3,
      panel: "Adani NDCR 550W TOPCon", inverter: "Deye 3kW on-grid",
      emiYears: 5, validDays: "15", pm: "Rohit Sahu"
    },
    settings: { tariff: "8.2" },
    calc: {
      kw: 3, rate: 60000, base: 180000, totalPayable: 204840, subsidy: 78000,
      netCost: 126840, residential: true, annualUnits: 4500, annualSavings: 36900,
      monthlySavings: 3075, payback: 3.4, lifetime: 1420000,
      emi3: 4123, emi5: 2723, emi7: 2130, emi10: 1580, panelQty: 6, panelWattage: 550, roofArea: 240,
      quoteNo: "SS/26-27/042"
    }
  };

  function tokens(payload) {
    var p = payload && payload.calc ? payload : DEMO;
    var f = p.form || DEMO.form, c = p.calc, st = p.settings || {};
    var bill = parseFloat(String(f.bill).replace(/[^0-9.]/g, "")) || 0;
    var annual = c.annualSavings || 0;
    var net = c.netCost || 0;

    // 25-year run: 5% tariff escalation, 0.5% module degradation
    var billsTotal = 0, cum = 0, yearly = annual, billYear = bill * 12, rows = {};
    var y10bill = bill;
    for (var y = 1; y <= 25; y++) {
      billsTotal += billYear;
      cum += yearly;
      if (y === 1 || y === 5 || y === 10 || y === 15 || y === 25) {
        rows["Y" + y] = { bill: yearly, cum: cum, net: cum - net };
      }
      if (y === 10) y10bill = billYear / 12;
      billYear *= 1.05;
      yearly = yearly * 1.05 * 0.995;
    }
    var lifetime = cum - net;
    var payback = annual > 0 ? net / annual : 0;
    var afterSolar = Math.max(bill - (c.monthlySavings || 0), 150);
    var base = c.base || 0;
    var systemPart = base * 0.82, bosPart = base - systemPart;
    var quoteDate = new Date();
    var valid = new Date(Date.now() + (parseFloat(f.validDays) || 15) * 864e5);
    var adYear1 = (c.totalPayable || 0) * 0.4;

    var out = {
      CUSTOMER_NAME: f.name && f.name.trim() ? f.name.trim() : "New customer",
      CUSTOMER_ADDRESS: f.address && f.address.trim() ? f.address.trim() : "Pendra, Chhattisgarh",
      SYSTEM_SIZE_KW: String(c.kw),
      PAYBACK_YEARS: payback.toFixed(1),
      // c.quoteNo is only ever real (backend-assigned) or absent — never invent a
      // look-alike number here. DEMO.calc.quoteNo below is the one legitimate
      // exception: it's shown only when previewing the proposal with no app data at all.
      QUOTE_NO: p.quoteNo || c.quoteNo || "Pending",
      QUOTE_DATE: dmy(quoteDate),
      VALID_UNTIL: dmy(valid),
      CURRENT_MONTHLY_BILL: inr(bill),
      BILL_YEAR_10: inr(y10bill),
      TOTAL_BILLS_25YR: inr(billsTotal),
      BILL_AFTER_SOLAR: inr(afterSolar),
      MONTHLY_SAVINGS: inr(c.monthlySavings),
      ANNUAL_SAVINGS: inr(annual),
      LIFETIME_SAVINGS: inr(lifetime),
      ROI_PERCENT: net > 0 ? (annual / net * 100).toFixed(1) : "0",
      RETURN_PER_RUPEE: net > 0 ? (cum / net).toFixed(1) : "0",
      QUOTE_TOKEN: p.token || "",
      WHATSAPP_URL: "https://wa.me/91" + String(COMPANY.SERVICE_NUMBER).replace(/[^0-9]/g, "").replace(/^0+/, "").replace(/^91/, ""),
      PANEL_QTY: String(c.panelQty),
      PANEL_WATTAGE: String(c.panelWattage),
      PANEL_BRAND: f.panel || "Adani NDCR",
      INVERTER_SPEC: f.inverter || "Deye on-grid",
      ROOF_AREA_SQFT: inr(c.roofArea),
      ANNUAL_GENERATION_KWH: inr(c.annualUnits),
      CO2_OFFSET_TONNES: ((c.annualUnits || 0) * 0.82 / 1000).toFixed(1),
      SYSTEM_COST: inr(base),
      GST: inr((c.totalPayable || 0) - base),
      TOTAL_PAYABLE: inr(c.totalPayable),
      SUBSIDY_AMOUNT: inr(c.subsidy),
      NET_COST: inr(net),
      RATE_SYSTEM: inr(systemPart),
      AMOUNT_SYSTEM: inr(systemPart),
      RATE_BOS: inr(bosPart),
      AMOUNT_BOS: inr(bosPart),
      EMI_3YR: inr(c.emi3),
      EMI_5YR: inr(c.emi5),
      EMI_7YR: inr(c.emi7),
      EMI_10YR: inr(c.emi10),
      AD_YEAR1: inr(adYear1),
      TAX_SAVED: inr(adYear1 * 0.3),
      GST_CREDIT: inr((c.totalPayable || 0) - base),
      EFFECTIVE_NET_COST: inr((c.totalPayable || 0) - adYear1 * 0.3 - ((c.totalPayable || 0) - base)),
      PM_NAME: f.pm || COMPANY.PM_NAME
    };
    ["Y1", "Y5", "Y10", "Y15", "Y25"].forEach(function (k) {
      var r = rows[k] || { bill: 0, cum: 0, net: 0 };
      out[k + "_BILL"] = inr(r.bill);
      out[k + "_CUM"] = inr(r.cum);
      out[k + "_NET"] = inr(Math.abs(r.net));
    });
    Object.keys(COMPANY).forEach(function (k) { if (!(k in out)) out[k] = COMPANY[k]; });
    return out;
  }

  function read() {
    try { return JSON.parse(localStorage.getItem("shubh.quote.v1")); } catch (e) { return null; }
  }
  function write(payload) {
    try { localStorage.setItem("shubh.quote.v1", JSON.stringify(payload)); } catch (e) {}
  }

  // Replaces every [[TOKEN]] in the live DOM under root — in text content AND in
  // attribute values (e.g. href="[[WHATSAPP_URL]]"), since the proposal page uses both.
  function fill(root, map) {
    root = root || document.body;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var nodes = [], n;
    while ((n = walker.nextNode())) { if (n.nodeValue.indexOf("[[") !== -1) nodes.push(n); }
    nodes.forEach(function (node) {
      node.nodeValue = node.nodeValue.replace(/\[\[([A-Z0-9_]+)\]\]/g, function (whole, key) {
        return key in map ? map[key] : whole;
      });
    });
    var elements = root.querySelectorAll ? root.querySelectorAll("*") : [];
    for (var i = 0; i < elements.length; i++) {
      var attrs = elements[i].attributes;
      for (var j = 0; j < attrs.length; j++) {
        var attr = attrs[j];
        if (attr.value.indexOf("[[") !== -1) {
          attr.value = attr.value.replace(/\[\[([A-Z0-9_]+)\]\]/g, function (whole, key) {
            return key in map ? map[key] : whole;
          });
        }
      }
    }
  }

  window.ShubhQuote = { COMPANY: COMPANY, tokens: tokens, read: read, write: write, fill: fill, inr: inr };
})();
