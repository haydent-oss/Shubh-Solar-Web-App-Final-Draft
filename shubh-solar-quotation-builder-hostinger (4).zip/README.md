# Shubh Solar Quotation Builder — static app + PHP/MySQL API

## Files
- `index.html`, `style.css`, `script.js` — the quotation builder (plain HTML/CSS/JS, no build step).
- `shubh-solar-quotation.html`, `proposal.css` — the 6-page customer-facing proposal (cover, savings, what-we-install, system design, subsidy & EMI, timeline & terms), opened by `?token=...` link. Uses the browser's own Print dialog for "Download PDF" (no server-side PDF engine needed). On screen it auto-scales the fixed-A4-size pages to fit narrow phone screens; printing ignores that scaling and paginates one physical page per sheet.
- `quote-data.js` — turns a saved quotation into the `[[TOKEN]]` values the proposal fills in; also the localStorage bridge used as an offline fallback.
- `api/` — PHP backend: `config.php` (your DB credentials), `db.php` (PDO + helpers, including the quotation-token generator), `quotations.php` (list/create/edit/delete + lookup-by-token), `settings.php` (read/update presets and company details).
- `database_mysql.sql` — schema + seed data (import this first).

## How it works
`script.js` calls `api/quotations.php` and `api/settings.php` on load. If the API responds, it becomes the source of truth (saved quotations and presets are shared across every device/browser). If it's unreachable — e.g. you open `index.html` directly without a PHP server — everything falls back to `localStorage`, and any quotation saved that way is clearly marked **"NOT SAVED ONLINE"** in the list and detail screens. It is never silently presented as if it reached the server.

Every quotation has two separate identifiers, both assigned by the PHP backend — never by the browser:
- **Quote number** (e.g. `SS/26-27/043`) — the human-readable number shown on the printed proposal, sequential per financial year.
- **Quote token** (a 32-character random string) — the identifier used in the proposal link (`shubh-solar-quotation.html?token=...`). It's what a customer's link actually opens by; it never changes when you edit a quotation.

Editing an existing quotation (Detail screen → "Edit quotation") updates its data in place — the token and quote number never change. Deleting a quotation asks for confirmation first and, if it was ever saved to the server, removes it from MySQL via `DELETE /api/quotations.php?id=...`.

## Deploy on Hostinger
1. **Database**: hPanel → Databases → create a MySQL database + user. Open phpMyAdmin, select it, and import `database_mysql.sql`.
2. **Credentials**: edit `api/config.php` — set `DB_HOST` (usually `localhost` on Hostinger), `DB_NAME`, `DB_USER`, `DB_PASS` to what you just created.
3. **Upload**: File Manager (or FTP) → `public_html` → upload everything, keeping `api/` as a subfolder.
4. Visit your domain. Create a test quotation, confirm it gets a real quote number and appears in the list without a "NOT SAVED ONLINE" badge — that confirms MySQL is connected.
5. Open the proposal from that quotation (Preview / Download / WhatsApp) and confirm all 6 pages render with your data, then use "Print / Download PDF" on that page to confirm the browser print dialog works and paginates cleanly.
6. Edit that same quotation and confirm the quote number and proposal link stay the same.
7. Delete a test quotation and confirm it disappears from the list.
8. Test "Send on WhatsApp" from a phone — it opens `wa.me` with the customer's number (if a valid 10-digit mobile was entered) or a blank-recipient WhatsApp chat with the message pre-filled otherwise.

## Notes
- `COMPANY_ID` in `api/config.php` must match a row in the `companies` table (the seed data already has one — no change needed unless you insert your own company).
- The API is intentionally single-tenant (one `COMPANY_ID`) and has no authentication yet — fine for an internal tool on a private URL, but add a login check in `api/db.php` before exposing this publicly.
- Company details shown on every proposal (GSTIN, service number, bank name, account number) are now editable from the Settings tab — no more static/dead "Edit company details" button.
- `emi_years_selected` and per-quote EMI columns already include the 10-year option.
- **The proposal's logo and social links need your input.** The design references `assets/shubh-solar-logo-icon.png`, which wasn't provided — the pages currently show the "Shubh Solar" text wordmark only. Instagram and Facebook footer buttons on the last page are hidden (rather than pointing at a fake URL) until you set `INSTAGRAM_URL` / `FACEBOOK_URL` in `quote-data.js`. Upload a logo file and give me its path, or the two real profile links, and I'll wire them back in. The WhatsApp footer button already works — it's built from the real service number in `quote-data.js`.
- The savings-over-time and monthly-generation charts on pages 2 and 4 are illustrative SVGs (fixed shapes), not plotted from each quotation's exact numbers — that's inherent to the design as given, not something this build added.
- **Colour printing / PDF**: the proposal forces `print-color-adjust: exact`, so the gradient cover and coloured panels are preserved instead of coming out black and white. If a particular Android print service still strips colour, open the print preview's **More settings** and tick **Background graphics** — a few Android print paths ignore the CSS and only honour that toggle. Chrome's own "Save as PDF" respects the CSS.
