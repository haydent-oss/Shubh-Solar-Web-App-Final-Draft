-- Shubh Solar Quotation Builder — MySQL/MariaDB schema (Hostinger-compatible)
-- Mirrors database.sql (PostgreSQL version); use this one on Hostinger's MySQL hosting.
-- Import via hPanel > Databases > phpMyAdmin, or: mysql -u USER -p DBNAME < database_mysql.sql

CREATE TABLE companies (
  id              CHAR(36) PRIMARY KEY,
  name            VARCHAR(120) NOT NULL DEFAULT 'Shubh Solar',
  gstin           VARCHAR(20) NOT NULL,
  service_number  VARCHAR(20) NOT NULL,
  phone           VARCHAR(20) NOT NULL,
  email           VARCHAR(120),
  website         VARCHAR(120),
  bank_name       VARCHAR(120) NOT NULL,
  bank_branch     VARCHAR(120),
  account_no      VARCHAR(30) NOT NULL,
  ifsc            VARCHAR(15) NOT NULL,
  bank_partner    VARCHAR(160),
  pendra_address  VARCHAR(200),
  pendra_phone    VARCHAR(20),
  bilaspur_address VARCHAR(200),
  bilaspur_phone  VARCHAR(20),
  cable_limit_m   INT NOT NULL DEFAULT 30,
  adv_pct         INT NOT NULL DEFAULT 30,
  del_pct         INT NOT NULL DEFAULT 50,
  com_pct         INT NOT NULL DEFAULT 20,
  quote_seq       INT NOT NULL DEFAULT 0,
  fy_label        VARCHAR(10) NOT NULL DEFAULT '26-27',
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
  id            CHAR(36) PRIMARY KEY,
  company_id    CHAR(36) NOT NULL,
  email         VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  name          VARCHAR(120) NOT NULL,
  phone         VARCHAR(20),
  role          ENUM('admin','field') NOT NULL DEFAULT 'field',
  lang_pref     ENUM('en','hi') NOT NULL DEFAULT 'en',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE settings (
  company_id      CHAR(36) PRIMARY KEY,
  package_rates   JSON NOT NULL,
  gst_percent     DECIMAL(5,2) NOT NULL DEFAULT 13.8,
  tariff          DECIMAL(6,2) NOT NULL DEFAULT 8.2,
  units_per_kw    DECIMAL(6,1) NOT NULL DEFAULT 1500,
  emi_rate        DECIMAL(5,2) NOT NULL DEFAULT 10.5,
  subsidy_cap     INT NOT NULL DEFAULT 78000,
  panel_wattage   INT NOT NULL DEFAULT 550,
  default_pm_name VARCHAR(120),
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE quotations (
  id                CHAR(36) PRIMARY KEY,
  quote_token       CHAR(32) NOT NULL UNIQUE, -- server-generated (bin2hex(random_bytes(16))); the authoritative identifier for opening/looking up a quotation
  company_id        CHAR(36) NOT NULL,
  created_by        CHAR(36),
  quote_no          VARCHAR(30) NOT NULL,
  status            ENUM('Draft','Sent','Won','Lost') NOT NULL DEFAULT 'Draft',
  lang              ENUM('en','hi') NOT NULL DEFAULT 'en',

  customer_name     VARCHAR(160) NOT NULL,
  address           VARCHAR(255),
  phone             VARCHAR(20),
  consumer_no       VARCHAR(40),
  category          ENUM('Residential','Commercial') NOT NULL DEFAULT 'Residential',
  avg_monthly_bill  DECIMAL(10,2) NOT NULL,
  kw                DECIMAL(5,2) NOT NULL,
  panel_brand       VARCHAR(120) NOT NULL,
  inverter_brand    VARCHAR(120) NOT NULL,
  emi_years_selected TINYINT NOT NULL DEFAULT 5,
  valid_days        INT NOT NULL DEFAULT 15,
  pm_name           VARCHAR(120),

  rate              DECIMAL(10,2) NOT NULL,
  base_cost         DECIMAL(12,2) NOT NULL,
  gst_amount        DECIMAL(12,2) NOT NULL,
  total_payable     DECIMAL(12,2) NOT NULL,
  subsidy           DECIMAL(12,2) NOT NULL DEFAULT 0,
  net_cost          DECIMAL(12,2) NOT NULL,
  annual_units      DECIMAL(10,1) NOT NULL,
  annual_savings    DECIMAL(12,2) NOT NULL,
  monthly_savings   DECIMAL(12,2) NOT NULL,
  payback_years     DECIMAL(5,2) NOT NULL,
  lifetime_savings  DECIMAL(14,2) NOT NULL,
  emi_3yr           DECIMAL(10,2) NOT NULL,
  emi_5yr           DECIMAL(10,2) NOT NULL,
  emi_7yr           DECIMAL(10,2) NOT NULL,
  emi_10yr          DECIMAL(10,2) NOT NULL,
  panel_qty         INT NOT NULL,
  panel_wattage     INT NOT NULL,
  roof_area_sqft    INT NOT NULL,
  valid_until       DATE NOT NULL,

  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_company_quoteno (company_id, quote_no),
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE INDEX idx_quotations_company_status ON quotations (company_id, status);
CREATE INDEX idx_quotations_created_at ON quotations (created_at DESC);
CREATE INDEX idx_quotations_token ON quotations (quote_token);

-- ============ Seed data ============

SET @company_id = 'a0000000-0000-0000-0000-000000000001';

INSERT INTO companies (id, name, gstin, service_number, phone, email, website, bank_name, bank_branch, account_no, ifsc, bank_partner, pendra_address, pendra_phone, bilaspur_address, bilaspur_phone, fy_label)
VALUES (@company_id, 'Shubh Solar', '22ABCDE1234F1Z5', '98271 00000', '98271 44120', 'shubhsolar.pendra@gmail.com', 'www.shubhsolar.in', 'State Bank of India', 'Pendra Branch', '3842 7715 902', 'SBIN0004821', 'SBI Surya Ghar / Union Bank rooftop loan', 'Main Road, near Bus Stand, Pendra, Dist. GPM 495117', '98271 44120', 'Shop 12, Vyapar Vihar Road, Bilaspur 495001', '94255 09813', '26-27');

INSERT INTO settings (company_id, package_rates, gst_percent, tariff, units_per_kw, emi_rate, subsidy_cap, default_pm_name)
VALUES (@company_id, JSON_OBJECT('2', 68000, '3', 60000, '5', 54000, '10', 49000), 13.8, 8.2, 1500, 10.5, 78000, 'Rohit Sahu');

INSERT INTO users (id, company_id, email, password_hash, name, role)
VALUES (UUID(), @company_id, 'akhilesh@shubhsolar.in', '<bcrypt-hash>', 'Akhilesh Jaiswal', 'admin');

INSERT INTO quotations (
  id, quote_token, company_id, quote_no, status, customer_name, address, phone, category, avg_monthly_bill, kw,
  panel_brand, inverter_brand, emi_years_selected, valid_days, pm_name,
  rate, base_cost, gst_amount, total_payable, subsidy, net_cost, annual_units, annual_savings,
  monthly_savings, payback_years, lifetime_savings, emi_3yr, emi_5yr, emi_7yr, emi_10yr,
  panel_qty, panel_wattage, roof_area_sqft, valid_until
) VALUES
(UUID(), '51f2799c0655461681e05e186b59b65f', @company_id, 'SS/26-27/041', 'Sent', 'Ramkumar Jaiswal', 'Ward 4, Pendra Road, Dist. GPM, Chhattisgarh 495117', '98271 44120', 'Residential', 3200, 3,
 'Adani NDCR 550W TOPCon', 'Deye 3kW on-grid', 5, 15, 'Rohit Sahu',
 60000, 180000, 24840, 204840, 78000, 126840, 4500, 36900,
 3075, 3.4, 1420000, 4123, 2723, 2130, 1580,
 6, 550, 240, DATE_ADD(CURDATE(), INTERVAL 15 DAY)),
(UUID(), '514f95026ac042b68011d419a1bd49be', @company_id, 'SS/26-27/040', 'Won', 'Sunita Devi Kesharwani', 'Ratanpur', '94255 09813', 'Residential', 5200, 5,
 'Waaree 545W Mono PERC', 'Deye 5kW on-grid', 5, 15, 'Rohit Sahu',
 54000, 270000, 37260, 307260, 78000, 229260, 7500, 56880,
 4740, 4.0, 2150000, 7480, 4940, 3860, 2860,
 10, 545, 400, DATE_ADD(CURDATE(), INTERVAL 15 DAY)),
(UUID(), 'e9bac9276618448cadb13d93298c60cf', @company_id, 'SS/26-27/039', 'Draft', 'Agrawal Kirana Store', 'Bilaspur, Sarkanda', '90098 71234', 'Commercial', 11600, 10,
 'Adani NDCR 550W TOPCon', 'Solis 10kW three-phase', 5, 15, 'Rohit Sahu',
 49000, 490000, 67620, 557620, 0, 557620, 15000, 123000,
 10250, 4.53, 4905000, 18130, 11983, 9399, 7526,
 19, 550, 800, DATE_ADD(CURDATE(), INTERVAL 15 DAY));
