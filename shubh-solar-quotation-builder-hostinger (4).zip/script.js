/* Shubh Solar Quotation Builder — vanilla JS rewrite (no eval/new Function, plain DOM). */
(function () {
  "use strict";

  var STATUS_COLORS = { Draft: "#6B7A88", Sent: "#1878C0", Won: "#2FA84F", Lost: "#D14343" };
  var STORAGE_KEY = "shubhSolarQuotationApp:v1";

  // Seed rows carry a "local-" prefixed token because they were never actually POSTed to
  // an API in this demo state — they render with the same "not synced" badge real unsynced
  // drafts get, which is honest: nothing here has touched a real database yet.
  var SEED_QUOTES = [
    { id: "q1", token: "local-a1e6c2d03f184b9a9c2e11f0a2b3c4d1", quoteNo: "SS/26-27/041", name: "श्री रामकुमार जायसवाल", place: "Pendra Road", phone: "98271 44120", kw: 3, net: 126840, monthly: 3075, status: "Sent", date: "14 Aug", synced: false },
    { id: "q2", token: "local-b2f7d3e14a294cab8d3f22a1b3c4d5e2", quoteNo: "SS/26-27/040", name: "Sunita Devi Kesharwani", place: "Ratanpur", phone: "94255 09813", kw: 5, net: 229260, monthly: 4740, status: "Won", date: "11 Aug", synced: false },
    { id: "q3", token: "local-c3a8e4f25b3a4dbc9e4a33b2c4d5e6f3", quoteNo: "SS/26-27/039", name: "Agrawal Kirana Store", place: "Bilaspur, Sarkanda", phone: "90098 71234", kw: 10, net: 479610, monthly: 9450, status: "Draft", date: "09 Aug", synced: false }
  ];

  var TR = {
    en: {
      tabQuotes: "Quotations", tabNew: "New", tabSettings: "Settings", back: "Back",
      kicker_list: "FIELD TOOL", title_list: "Quotations",
      kicker_step1: "NEW QUOTATION", title_step1: "Customer",
      kicker_step2: "NEW QUOTATION", title_step2: "System & bill",
      kicker_step3: "NEW QUOTATION", title_step3: "Money",
      kicker_review: "READY TO SEND", title_review: "Review & send",
      kicker_detail: "SAVED QUOTATION", title_detail: "Customer file",
      kicker_settings: "PRESETS", title_settings: "Settings",
      filterAll: "All", filterDraft: "Draft", filterSent: "Sent", filterWon: "Won",
      statThisMonth: "THIS MONTH", statSent: "quotations sent", statConfirmed: "CONFIRMED", statBooked: "kW booked",
      noQuotes: 'No quotations yet. Tap "New quotation" to create the first one.',
      newQuotation: "+ New quotation",
      stepOf1: "STEP 1 OF 3", stepOf2: "STEP 2 OF 3", stepOf3: "STEP 3 OF 3",
      stepSub1: "Customer details", stepSub2: "System & bill", stepSub3: "Subsidy, EMI & validity",
      customerName: "CUSTOMER NAME *", namePh: "e.g. Ramkumar Jaiswal",
      address: "ADDRESS", addressPh: "Ward 4, Pendra Road, Dist. GPM",
      mobile: "MOBILE", consumerNo: "CONSUMER NO.",
      connectionType: "CONNECTION TYPE", residential: "Residential", commercial: "Commercial",
      noteResidential: "PM Surya Ghar subsidy applies — the proposal shows the residential subsidy panel.",
      noteCommercial: "No PM Surya Ghar subsidy. The proposal switches to accelerated depreciation and GST credit instead.",
      avgBill: "AVERAGE MONTHLY BILL (₹)", presetPackages: "SYSTEM SIZE (PRESET PACKAGES)", moduleBrand: "MODULE BRAND", inverter: "INVERTER",
      autoCalc: "AUTO-CALCULATED", modules: "Modules", roofArea: "Roof area needed", annualGen: "Annual generation",
      emiHighlight: "HIGHLIGHT AN EMI OPTION", validDays: "VALID FOR (DAYS)", pm: "PROJECT MANAGER",
      whatCustomerSees: "WHAT THE CUSTOMER WILL SEE", monthlySavings: "Monthly savings", payback: "Payback period", lifetimeSavings: "25-year savings",
      proposalReady: "6-PAGE PROPOSAL · READY",
      previewProposal: "Preview full proposal", sendWhatsapp: "Send on WhatsApp", downloadPdf: "Download PDF", saveDraft: "Save to customer list",
      saveChanges: "Save changes",
      sendingNote: "Sending marks this quotation Sent and files it under the customer's name. You can reopen and revise it any time — the quotation number stays the same.",
      quotationLabel: "QUOTATION", quotationPending: "Assigned when saved", netInvestment: "NET INVESTMENT", savesPerMonth: "SAVES / MONTH",
      updateStatus: "UPDATE STATUS", resendWhatsapp: "Resend on WhatsApp", openProposal: "Open proposal",
      system: "SYSTEM", quoteNo: "QUOTE NO.", netCost: "NET COST", savesMonth: "SAVES / MONTH",
      statusSent: "Sent", statusWon: "Won", statusLost: "Lost",
      settingsIntro: "Presets used by every quotation. Change them once here — old quotations keep the rates they were made with.",
      packageRates: "PACKAGE RATES (₹ / kW)", assumptionsSlabs: "ASSUMPTIONS & SLABS", companyDetails: "COMPANY DETAILS ON EVERY PROPOSAL",
      gst: "GST", gstHint: "% added to system cost", tariff: "Tariff", tariffHint: "₹ per unit today",
      generation: "Generation", generationHint: "units per kW per year", emiRate: "EMI rate", emiRateHint: "% p.a. from the bank",
      subsidyCap: "Subsidy cap", subsidyCapHint: "₹ for 3 kW and above",
      gstinLabel: "GSTIN", serviceNumberLabel: "Service number", bankNameLabel: "Bank name", accountNoLabel: "Account no.",
      pageThumbs: ["Cover", "Savings comparison", "What we install", "System design", "Subsidy & EMI options", "Timeline & signatures"],
      kwPackageWord: "package", followUpWord: "Follow-up reminder: call {n} if there is no reply within 3 days of sending.",
      editQuotation: "Edit quotation", deleteQuotation: "Delete quotation", confirmDelete: "Delete this quotation? This cannot be undone.",
      cancel: "Cancel", yesDelete: "Yes, delete", notSynced: "NOT SAVED ONLINE"
    },
    hi: {
      tabQuotes: "कोटेशन", tabNew: "नया", tabSettings: "सेटिंग्स", back: "पीछे",
      kicker_list: "फील्ड टूल", title_list: "कोटेशन",
      kicker_step1: "नया कोटेशन", title_step1: "ग्राहक",
      kicker_step2: "नया कोटेशन", title_step2: "सिस्टम व बिल",
      kicker_step3: "नया कोटेशन", title_step3: "पैसा",
      kicker_review: "भेजने के लिए तैयार", title_review: "रिव्यू व भेजें",
      kicker_detail: "सेव्ड कोटेशन", title_detail: "ग्राहक फाइल",
      kicker_settings: "प्रीसेट", title_settings: "सेटिंग्स",
      filterAll: "सभी", filterDraft: "ड्राफ्ट", filterSent: "भेजा गया", filterWon: "जीता",
      statThisMonth: "इस महीने", statSent: "कोटेशन भेजे", statConfirmed: "कन्फर्म", statBooked: "kW बुक",
      noQuotes: 'अभी कोई कोटेशन नहीं। "नया कोटेशन" दबाएं।',
      newQuotation: "+ नया कोटेशन",
      stepOf1: "स्टेप 1/3", stepOf2: "स्टेप 2/3", stepOf3: "स्टेप 3/3",
      stepSub1: "ग्राहक की जानकारी", stepSub2: "बिल और सिस्टम साइज़", stepSub3: "सब्सिडी, EMI और वैधता",
      customerName: "ग्राहक का नाम *", namePh: "जैसे श्री रामकुमार जायसवाल",
      address: "पता", addressPh: "वार्ड 4, पेंड्रा रोड, जिला GPM",
      mobile: "मोबाइल", consumerNo: "उपभोक्ता क्रमांक",
      connectionType: "कनेक्शन प्रकार", residential: "घरेलू", commercial: "व्यावसायिक",
      noteResidential: "PM सूर्य घर सब्सिडी लागू होगी — प्रस्ताव में घरेलू सब्सिडी पैनल दिखेगा।",
      noteCommercial: "PM सूर्य घर सब्सिडी लागू नहीं। प्रस्ताव में त्वरित मूल्यह्रास और GST क्रेडिट दिखेगा।",
      avgBill: "औसत मासिक बिल (₹)", presetPackages: "सिस्टम साइज़ (तय पैकेज)", moduleBrand: "मॉड्यूल ब्रांड", inverter: "इन्वर्टर",
      autoCalc: "ऑटो-कैलकुलेटेड", modules: "मॉड्यूल", roofArea: "छत का क्षेत्र", annualGen: "वार्षिक उत्पादन",
      emiHighlight: "EMI ऑप्शन चुनें", validDays: "वैधता (दिन)", pm: "प्रोजेक्ट मैनेजर",
      whatCustomerSees: "ग्राहक को क्या दिखेगा", monthlySavings: "मासिक बचत", payback: "पेबैक अवधि", lifetimeSavings: "25 साल की बचत",
      proposalReady: "6-पेज प्रस्ताव · तैयार",
      previewProposal: "पूरा प्रस्ताव देखें", sendWhatsapp: "WhatsApp पर भेजें", downloadPdf: "PDF डाउनलोड करें", saveDraft: "ग्राहक लिस्ट में सेव करें",
      saveChanges: "बदलाव सेव करें",
      sendingNote: "भेजने पर यह कोटेशन 'भेजा गया' हो जाएगा और ग्राहक के नाम से सेव होगा। कोटेशन नंबर वही रहेगा।",
      quotationLabel: "कोटेशन", quotationPending: "सेव होने पर मिलेगा", netInvestment: "नेट निवेश", savesPerMonth: "मासिक बचत",
      updateStatus: "स्टेटस अपडेट करें", resendWhatsapp: "फिर WhatsApp पर भेजें", openProposal: "प्रस्ताव खोलें",
      system: "सिस्टम", quoteNo: "कोटेशन नं.", netCost: "नेट लागत", savesMonth: "मासिक बचत",
      statusSent: "भेजा गया", statusWon: "जीता", statusLost: "खोया",
      settingsIntro: "हर कोटेशन में यही प्रीसेट लगते हैं। यहां एक बार बदलें — पुराने कोटेशन अपनी पुरानी दर पर रहेंगे।",
      packageRates: "पैकेज दरें (₹ / kW)", assumptionsSlabs: "मान्यताएं व स्लैब", companyDetails: "हर प्रस्ताव में कंपनी विवरण",
      gst: "GST", gstHint: "सिस्टम लागत में % जुड़ेगा", tariff: "टैरिफ", tariffHint: "₹ प्रति यूनिट आज",
      generation: "उत्पादन", generationHint: "यूनिट प्रति kW प्रति वर्ष", emiRate: "EMI दर", emiRateHint: "% प्रति वर्ष बैंक से",
      subsidyCap: "सब्सिडी सीमा", subsidyCapHint: "₹, 3 kW व अधिक के लिए",
      gstinLabel: "GSTIN", serviceNumberLabel: "सर्विस नंबर", bankNameLabel: "बैंक का नाम", accountNoLabel: "खाता नं.",
      pageThumbs: ["कवर", "बचत तुलना", "हम क्या लगाते हैं", "सिस्टम डिज़ाइन", "सब्सिडी व EMI विकल्प", "टाइमलाइन व हस्ताक्षर"],
      kwPackageWord: "पैकेज", followUpWord: "{n} को 3 दिन में जवाब न आए तो कॉल करें।",
      editQuotation: "कोटेशन बदलें", deleteQuotation: "कोटेशन हटाएं", confirmDelete: "इस कोटेशन को हटाएं? यह वापस नहीं हो सकता।",
      cancel: "रद्द करें", yesDelete: "हां, हटाएं", notSynced: "ऑनलाइन सेव नहीं"
    }
  };

  var DEFAULT_FORM = {
    name: "", address: "", phone: "", consumerNo: "",
    category: "Residential", bill: "3200", kw: 3,
    panel: "Adani NDCR 550W TOPCon", inverter: "Deye 3kW on-grid",
    emiYears: 5, validDays: "15", pm: "Rohit Sahu"
  };

  var state = {
    tab: "quotes", screen: "list", filter: "All", detailId: null, toast: null, errorMsg: null, saveError: null, lang: "en",
    editingId: null, confirmDeleteId: null,
    quotes: SEED_QUOTES,
    form: Object.assign({}, DEFAULT_FORM),
    settings: {
      rates: { 2: 68000, 3: 60000, 5: 54000, 10: 49000 },
      gstPercent: "13.8", tariff: "8.2", unitsPerKw: "1500",
      emiRate: "10.5", subsidyCap: "78000",
      gstin: "22ABCDE1234F1Z5", serviceNumber: "98271 00000",
      bankName: "SBI, Pendra", accountNo: "3842 7715 902"
    }
  };

  function num(v) { var n = parseFloat(String(v).replace(/[^0-9.]/g, "")); return isNaN(n) ? 0 : n; }
  function inr(n) { return Math.round(Number(n) || 0).toLocaleString("en-IN"); }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

  // Local-only identifier used ONLY while a quotation hasn't (yet) been confirmed-saved
  // by the PHP/MySQL backend. It is never treated as the authoritative quote token —
  // it's prefixed so it can never collide with or be mistaken for a server token
  // (server tokens are 32 raw hex chars with no prefix). See commitQuote().
  function newLocalToken() {
    if (window.crypto && window.crypto.randomUUID) return "local-" + window.crypto.randomUUID();
    return "local-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  }

  // API_BASE points at the PHP backend (api/quotations.php, api/settings.php). If it's
  // unreachable (e.g. running as plain static files with no PHP server), everything
  // falls back to localStorage-only, so the app still works standalone — but anything
  // saved that way is clearly marked "not saved online" (synced:false), never silently
  // presented as if it reached the server.
  var API_BASE = "api/";
  var apiAvailable = false;

  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ quotes: state.quotes, form: state.form, settings: state.settings, lang: state.lang })); }
    catch (e) { console.warn("Could not save quotation data:", e); }
  }
  function restoreLocal() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      var saved = JSON.parse(raw);
      if (!saved || typeof saved !== "object") return;
      if (Array.isArray(saved.quotes) && saved.quotes.length) {
        state.quotes = saved.quotes.map(function (q) { return q.token ? q : Object.assign({}, q, { token: newLocalToken(), synced: false }); });
      }
      if (saved.form) state.form = Object.assign({}, state.form, saved.form);
      if (saved.settings) state.settings = Object.assign({}, state.settings, saved.settings, { rates: Object.assign({}, state.settings.rates, saved.settings.rates || {}) });
      if (saved.lang === "hi") state.lang = "hi";
      persist();
    } catch (e) { console.warn("Could not restore saved quotations:", e); }
  }
  function restore() {
    restoreLocal(); // local draft form + immediate paint
    Promise.all([
      fetch(API_BASE + "quotations.php").then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); }),
      fetch(API_BASE + "settings.php").then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
    ]).then(function (results) {
      var quotesRes = results[0], settingsRes = results[1];
      if (!quotesRes.ok || !quotesRes.body || !quotesRes.body.success) return Promise.reject();
      apiAvailable = true;
      if (Array.isArray(quotesRes.body.data) && quotesRes.body.data.length) state.quotes = quotesRes.body.data;
      if (settingsRes.ok && settingsRes.body && settingsRes.body.success && settingsRes.body.data) {
        var sd = settingsRes.body.data;
        state.settings = Object.assign({}, state.settings, sd, { rates: Object.assign({}, state.settings.rates, sd.rates || {}) });
      }
      persist();
      render();
    }).catch(function () { console.warn("PHP API not reachable — using localStorage only."); });
  }

  function calc() {
    var f = state.form, st = state.settings;
    var kw = num(f.kw) || 0;
    var rate = st.rates[kw] || st.rates[3] || 60000;
    var base = kw * rate;
    var gst = base * num(st.gstPercent) / 100;
    var totalPayable = base + gst;
    var residential = f.category === "Residential";
    var subsidy = 0;
    if (residential) {
      if (kw <= 1) subsidy = 30000;
      else if (kw < 3) subsidy = 60000;
      else subsidy = num(st.subsidyCap);
    }
    var netCost = Math.max(totalPayable - subsidy, 0);
    var annualUnits = kw * num(st.unitsPerKw);
    var bill = num(f.bill);
    var annualSavings = Math.min(annualUnits * num(st.tariff), bill * 12 * 1.05);
    var monthlySavings = annualSavings / 12;
    var payback = annualSavings > 0 ? netCost / annualSavings : 0;
    var lifetime = 0, yearly = annualSavings;
    for (var y = 0; y < 25; y++) { lifetime += yearly; yearly = yearly * 1.05 * 0.995; }
    lifetime = Math.max(lifetime - netCost, 0);
    function emi(years) {
      var r = num(st.emiRate) / 1200, n = years * 12;
      if (!r) return netCost / n;
      return netCost * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
    }
    var wattage = 550;
    var validUntil = new Date(Date.now() + num(f.validDays) * 864e5).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
    // NOTE: no quoteNo here. The quote number is assigned ONLY by the backend on save
    // (Issue 2) — a client-side placeholder used to be hardcoded here ("SS/26-27/042"),
    // which meant every unsent quotation showed the same fake number. The UI now shows
    // "Assigned when saved" until a real save (POST/PUT) returns the authoritative number.
    return {
      kw: kw, rate: rate, base: base, totalPayable: totalPayable, subsidy: subsidy, netCost: netCost, residential: residential,
      annualUnits: annualUnits, annualSavings: annualSavings, monthlySavings: monthlySavings, payback: payback, lifetime: lifetime,
      emi3: emi(3), emi5: emi(5), emi7: emi(7), emi10: emi(10),
      panelQty: Math.ceil(kw * 1000 / wattage), panelWattage: wattage,
      roofArea: Math.round(kw * 80), validUntil: validUntil
    };
  }

  function snapshotFromSummary(q) {
    var st = state.settings, kw = q.kw || 3;
    var subsidy = kw <= 1 ? 30000 : (kw < 3 ? 60000 : num(st.subsidyCap));
    var netCost = q.net || 0, totalPayable = netCost + subsidy;
    var gstFrac = num(st.gstPercent) / (100 + num(st.gstPercent));
    var base = totalPayable * (1 - gstFrac);
    var monthlySavings = q.monthly || 0, annualSavings = monthlySavings * 12;
    var annualUnits = kw * num(st.unitsPerKw);
    var payback = annualSavings > 0 ? netCost / annualSavings : 0;
    var lifetime = 0, yearly = annualSavings;
    for (var y = 0; y < 25; y++) { lifetime += yearly; yearly = yearly * 1.05 * 0.995; }
    lifetime = Math.max(lifetime - netCost, 0);
    function emi(years) {
      var r = num(st.emiRate) / 1200, n = years * 12;
      if (!r) return netCost / n;
      return netCost * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
    }
    return {
      form: { name: q.name, address: q.place, phone: q.phone, category: "Residential", bill: String(Math.round(monthlySavings)), panel: "Adani NDCR 550W TOPCon", inverter: "Deye " + kw + "kW on-grid", emiYears: 5, validDays: "15", pm: "Rohit Sahu" },
      settings: Object.assign({}, st),
      calc: { kw: kw, rate: st.rates[kw] || st.rates[3] || 60000, base: base, totalPayable: totalPayable, subsidy: subsidy, netCost: netCost, residential: true, annualUnits: annualUnits, annualSavings: annualSavings, monthlySavings: monthlySavings, payback: payback, lifetime: lifetime, emi3: emi(3), emi5: emi(5), emi7: emi(7), emi10: emi(10), panelQty: Math.ceil(kw * 1000 / 550), panelWattage: 550, roofArea: Math.round(kw * 80), validUntil: new Date(Date.now() + 15 * 864e5).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) }
    };
  }

  function proposalUrl(token) { return "shubh-solar-quotation.html?token=" + encodeURIComponent(token); }
  function proposalAbsoluteUrl(token) {
    var dir = window.location.pathname.replace(/index\.html$/i, "").replace(/\/[^/]*$/, "/");
    return window.location.origin + dir + "shubh-solar-quotation.html?token=" + encodeURIComponent(token);
  }
  function openProposal(token) {
    var url = proposalUrl(token);
    try { window.location.href = url; }
    catch (e) { window.top.location.href = url; }
  }
  // Writes the FULL data a saved quote needs so the proposal page can render it purely
  // from localStorage as a same-device fallback. When the API is reachable, the
  // proposal page's own fetch-by-token is the source of truth instead (see that file).
  function publishQuote(q) {
    if (!q || !window.ShubhQuote) return;
    var payload = q.snapshot || snapshotFromSummary(q);
    window.ShubhQuote.write(Object.assign({}, payload, { token: q.token, quoteNo: q.quoteNo }));
  }

  function openWhatsApp(q) {
    var digits = String(q.phone || "").replace(/[^0-9]/g, "").replace(/^0+/, "");
    if (digits.length === 10) digits = "91" + digits;
    else if (digits.length !== 12) digits = ""; // don't guess — fall back to a contact-picker link below
    var link = proposalAbsoluteUrl(q.token);
    var lines = state.lang === "hi"
      ? ["नमस्ते " + q.name + ",", "आपका सोलर कोटेशन (" + q.quoteNo + ") तैयार है।", "सिस्टम " + q.kw + " kW · नेट लागत ₹" + inr(q.net) + " · मासिक बचत ₹" + inr(q.monthly), "पूरा प्रस्ताव: " + link]
      : ["Hi " + q.name + ",", "Your solar quotation (" + q.quoteNo + ") is ready.", "System " + q.kw + " kW · Net cost ₹" + inr(q.net) + " · Saves ₹" + inr(q.monthly) + "/mo", "Full proposal: " + link];
    var text = encodeURIComponent(lines.join("\n"));
    var waUrl = "https://wa.me/" + digits + "?text=" + text;
    window.open(waUrl, "_blank");
  }

  var toastTimer = null;
  function flash(msg) {
    state.toast = msg;
    render();
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { state.toast = null; render(); }, 3200);
  }

  function goStep(n) { state.screen = "step" + n; state.tab = "new"; state.errorMsg = null; render(); }
  function next() {
    var s = state.screen, f = state.form;
    if (s === "step1") {
      if (!f.name.trim()) { state.errorMsg = "Please enter customer name."; return render(); }
      var digits = f.phone.replace(/[^0-9]/g, "").replace(/^91/, "");
      if (digits && (digits.length !== 10 || !/^[6-9]/.test(digits))) { state.errorMsg = "Please enter a valid 10-digit mobile number."; return render(); }
      return goStep(2);
    }
    if (s === "step2") {
      if (num(f.bill) <= 0) { state.errorMsg = "Please enter the average monthly bill."; return render(); }
      return goStep(3);
    }
    if (s === "step3") { state.screen = "review"; state.errorMsg = null; state.saveError = null; return render(); }
  }
  function back() {
    var s = state.screen;
    if (s === "step2") return goStep(1);
    if (s === "step3") return goStep(2);
    if (s === "review") return goStep(3);
    state.screen = "list"; state.tab = "quotes"; state.detailId = null; state.errorMsg = null; state.editingId = null; render();
  }

  // ---------- save / edit / delete (all against the same PHP endpoint) ----------

  function buildLocalEntry(status, editing) {
    var c = calc(), f = state.form;
    return {
      id: editing ? editing.id : "local-" + Date.now(),
      token: editing ? editing.token : newLocalToken(),
      quoteNo: editing ? editing.quoteNo : "Pending",
      name: f.name.trim() || "Untitled customer",
      place: f.address.split(",").slice(-1)[0].trim() || "Pendra",
      phone: f.phone || "—", kw: c.kw, net: c.netCost, monthly: c.monthlySavings, status: status,
      date: editing ? editing.date : new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short" }),
      synced: false,
      snapshot: { form: Object.assign({}, f), settings: Object.assign({}, state.settings), calc: c }
    };
  }

  function upsertQuote(entry, matchId) {
    var idx = -1;
    for (var i = 0; i < state.quotes.length; i++) {
      if (state.quotes[i].id === matchId || state.quotes[i].id === entry.id) { idx = i; break; }
    }
    if (idx !== -1) {
      state.quotes = state.quotes.slice();
      state.quotes[idx] = entry;
    } else {
      state.quotes = [entry].concat(state.quotes);
    }
    persist();
  }

  // Single save path used by Preview / WhatsApp / Download / Save-to-list / Save-changes.
  // Resolves with the final entry. NEVER silently claims a server save that didn't
  // happen (Issue 10): on any failure, state.saveError is set with a clear message and
  // the caller is responsible for showing it, while the work itself is preserved locally
  // (synced:false) so nothing typed is lost.
  function commitQuote(status) {
    state.saveError = null;
    var editing = state.editingId ? state.quotes.find(function (q) { return q.id === state.editingId; }) : null;
    var localEntry = buildLocalEntry(status, editing);

    if (!apiAvailable) {
      state.saveError = "Quotation could not be saved to the server (offline). Kept on this device only — please retry once you're back online.";
      upsertQuote(localEntry, editing ? editing.id : null);
      render();
      return Promise.resolve(localEntry);
    }

    var f = state.form, c = calc();
    var url = API_BASE + "quotations.php" + (editing ? ("?id=" + encodeURIComponent(editing.id)) : "");
    var method = editing ? "PUT" : "POST";
    return fetch(url, { method: method, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ form: f, calc: c, status: status }) })
      .then(function (r) { return r.json().then(function (body) { return { ok: r.ok, body: body }; }); })
      .then(function (res) {
        if (!res.ok || !res.body || !res.body.success) {
          state.saveError = "Quotation could not be saved to the server. " + (res.body && res.body.error ? res.body.error : "Please retry.");
          upsertQuote(localEntry, editing ? editing.id : null);
          render();
          return localEntry;
        }
        var saved = Object.assign({}, res.body.data, { synced: true });
        upsertQuote(saved, editing ? editing.id : localEntry.id);
        state.editingId = saved.id; // further commits in this same review session become edits, not duplicates
        render();
        return saved;
      })
      .catch(function () {
        state.saveError = "Quotation could not be saved to the server. Please check your connection and retry.";
        upsertQuote(localEntry, editing ? editing.id : null);
        render();
        return localEntry;
      });
  }

  function deleteQuote(id) {
    var q = state.quotes.find(function (x) { return x.id === id; });
    state.confirmDeleteId = null;
    if (!q) { render(); return; }
    if (q.synced && apiAvailable) {
      fetch(API_BASE + "quotations.php?id=" + encodeURIComponent(id), { method: "DELETE" })
        .then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
        .then(function (res) {
          if (res.ok && res.body && res.body.success) {
            state.quotes = state.quotes.filter(function (x) { return x.id !== id; });
            persist();
            state.screen = "list"; state.tab = "quotes"; state.detailId = null;
            flash("Quotation deleted.");
          } else {
            flash("Could not delete: " + (res.body && res.body.error ? res.body.error : "unknown error"));
          }
          render();
        })
        .catch(function () { flash("Could not delete — check your connection and retry."); render(); });
    } else {
      // Never reached the server (or API currently unreachable) — safe to drop locally.
      state.quotes = state.quotes.filter(function (x) { return x.id !== id; });
      persist();
      state.screen = "list"; state.tab = "quotes"; state.detailId = null;
      flash("Quotation deleted.");
      render();
    }
  }

  function startEdit(q) {
    var snap = q.snapshot || snapshotFromSummary(q);
    state.form = Object.assign({}, DEFAULT_FORM, snap.form);
    if (snap.settings) state.settings = Object.assign({}, state.settings, snap.settings, { rates: Object.assign({}, state.settings.rates, snap.settings.rates || {}) });
    state.editingId = q.id;
    goStep(1);
  }

  function setForm(k, v) { state.form[k] = v; state.errorMsg = null; persist(); }
  function setSetting(k, v) {
    state.settings[k] = v; persist();
    if (apiAvailable) {
      var body = {}; body[k] = v;
      fetch(API_BASE + "settings.php", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
        .then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
        .then(function (res) { if (!res.ok || !res.body || !res.body.success) flash("Could not sync setting to the server."); })
        .catch(function () { flash("Could not sync setting to the server."); });
    }
  }
  function setRate(k, v) {
    state.settings.rates[k] = v; persist();
    if (apiAvailable) {
      fetch(API_BASE + "settings.php", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rates: state.settings.rates }) })
        .then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
        .then(function (res) { if (!res.ok || !res.body || !res.body.success) flash("Could not sync rate to the server."); })
        .catch(function () { flash("Could not sync rate to the server."); });
    }
  }

  // ---------- rendering ----------
  function L() { return TR[state.lang] || TR.en; }

  function chipClass(active, extra) { return "chip" + (active ? " active" : "") + (extra ? " " + extra : ""); }

  function renderShellHeader() {
    var l = L();
    var titleMap = { list: ["kicker_list", "title_list"], step1: ["kicker_step1", "title_step1"], step2: ["kicker_step2", "title_step2"], step3: ["kicker_step3", "title_step3"], review: ["kicker_review", "title_review"], detail: ["kicker_detail", "title_detail"], settings: ["kicker_settings", "title_settings"] };
    var tk = titleMap[state.screen] || titleMap.list;
    var showBack = state.screen !== "list" && state.screen !== "settings";
    return '<div class="phone-header">' +
      '<div style="flex:1;min-width:0">' +
        '<div class="kicker">' + esc(l[tk[0]]) + '</div>' +
        '<div class="title">' + esc(l[tk[1]]) + '</div>' +
      '</div>' +
      '<div class="lang-toggle">' +
        '<button data-act="lang" data-val="en" class="' + (state.lang === "en" ? "active" : "") + '">EN</button>' +
        '<button data-act="lang" data-val="hi" class="' + (state.lang === "hi" ? "active" : "") + '">हिं</button>' +
      '</div>' +
      (showBack ? '<button class="back-btn" data-act="back">' + esc(l.back) + '</button>' : '') +
    '</div>' +
    (state.errorMsg ? '<div class="error-bar">' + esc(state.errorMsg) + '</div>' : '');
  }

  function renderList() {
    var l = L(), q = state.quotes;
    var filters = ["All", "Draft", "Sent", "Won"];
    var flabels = { All: l.filterAll, Draft: l.filterDraft, Sent: l.filterSent, Won: l.filterWon };
    var visible = q.filter(function (x) { return state.filter === "All" || x.status === state.filter; });
    var statQuotes = q.filter(function (x) { return x.status !== "Draft"; }).length;
    var statWonKw = q.filter(function (x) { return x.status === "Won"; }).reduce(function (a, x) { return a + x.kw; }, 0);
    var html = '<div class="filters">' + filters.map(function (f) {
      return '<button class="filter-chip' + (state.filter === f ? " active" : "") + '" data-act="filter" data-val="' + f + '">' + esc(flabels[f]) + '</button>';
    }).join("") + '</div>';
    html += '<div class="stats">' +
      '<div class="stat-card"><div class="stat-label">' + esc(l.statThisMonth) + '</div><div class="stat-value" style="color:var(--navy)">' + statQuotes + '</div><div class="note">' + esc(l.statSent) + '</div></div>' +
      '<div class="stat-card"><div class="stat-label">' + esc(l.statConfirmed) + '</div><div class="stat-value" style="color:var(--green)">' + statWonKw + '</div><div class="note">' + esc(l.statBooked) + '</div></div>' +
    '</div>';
    if (visible.length) {
      html += visible.map(function (x) {
        return '<button class="quote-card" data-act="open-detail" data-id="' + x.id + '">' +
          '<div class="qc-main">' +
            '<div class="name">' + esc(x.name) + '</div>' +
            '<div class="meta">' + esc(x.place) + ' · ' + x.kw + ' kW · ' + esc(x.date) + '</div>' +
            '<div class="net">Net <strong>₹' + inr(x.net) + '</strong> · saves ₹' + inr(x.monthly) + '/mo</div>' +
          '</div>' +
          '<span class="qc-side">' +
            '<span class="pill" style="background:' + (STATUS_COLORS[x.status] || "#6B7A88") + '">' + esc(x.status) + '</span>' +
            (x.synced === false ? '<span class="badge-unsynced">' + esc(l.notSynced) + '</span>' : '') +
          '</span>' +
        '</button>';
      }).join("");
    } else {
      html += '<div class="empty-state">' + esc(l.noQuotes) + '</div>';
    }
    html += '<button class="btn-primary" data-act="new-quotation">' + esc(l.newQuotation) + '</button>';
    return html;
  }

  function renderStep1() {
    var l = L(), f = state.form;
    return '<div class="progress"><span class="on"></span><span></span><span></span></div>' +
      '<div><div class="step-kicker">' + esc(l.stepOf1) + '</div><div class="step-title">' + esc(l.stepSub1) + '</div></div>' +
      '<label class="field"><span>' + esc(l.customerName) + '</span><input data-bind="name" value="' + esc(f.name) + '" placeholder="' + esc(l.namePh) + '"></label>' +
      '<label class="field"><span>' + esc(l.address) + '</span><textarea data-bind="address" rows="2" placeholder="' + esc(l.addressPh) + '">' + esc(f.address) + '</textarea></label>' +
      '<div class="row2">' +
        '<label class="field"><span>' + esc(l.mobile) + '</span><input data-bind="phone" inputmode="tel" maxlength="10" value="' + esc(f.phone) + '" placeholder="98xxxxxxxx"></label>' +
        '<label class="field"><span>' + esc(l.consumerNo) + '</span><input data-bind="consumerNo" value="' + esc(f.consumerNo) + '" placeholder="optional"></label>' +
      '</div>' +
      '<div><div class="section-label">' + esc(l.connectionType) + '</div><div class="chip-row">' +
        '<button class="' + chipClass(f.category === "Residential") + '" data-act="category" data-val="Residential">' + esc(l.residential) + '</button>' +
        '<button class="' + chipClass(f.category === "Commercial") + '" data-act="category" data-val="Commercial">' + esc(l.commercial) + '</button>' +
      '</div><div class="note" style="margin-top:8px">' + esc(f.category === "Residential" ? l.noteResidential : l.noteCommercial) + '</div></div>';
  }

  function renderStep2() {
    var l = L(), f = state.form, c = calc();
    var bill = num(f.bill), suggested = Math.max(1, Math.round(bill / 1000));
    var sizeHint = bill > 0
      ? (state.lang === "hi"
        ? "₹" + inr(bill) + " बिल के लिए सामान्यतः " + suggested + " kW चाहिए। Adani 550W मॉड्यूल, साल में " + inr(c.annualUnits) + " यूनिट।"
        : "A ₹" + inr(bill) + " bill usually needs about " + suggested + " kW. Adani 550W modules, " + inr(c.annualUnits) + " units a year.")
      : (state.lang === "hi" ? "औसत बिल डालें, ऐप साइज़ सुझाएगा।" : "Enter the average bill and the app suggests a size.");
    var kwList = [2, 3, 5, 10];
    var panelBrands = ["Adani NDCR 550W TOPCon", "Waaree 545W Mono PERC", "Vikram Solar 540W", "Premier Energies 550W"];
    var inverterBrands = ["Deye 3kW on-grid", "Deye 5kW on-grid", "Solis 5kW on-grid", "Solis 10kW three-phase"];
    return '<div class="progress"><span class="on"></span><span class="on"></span><span></span></div>' +
      '<div><div class="step-kicker">' + esc(l.stepOf2) + '</div><div class="step-title">' + esc(l.stepSub2) + '</div></div>' +
      '<label class="field"><span>' + esc(l.avgBill) + '</span><input data-bind="bill" inputmode="numeric" value="' + esc(f.bill) + '" placeholder="3200" style="font-family:Poppins,sans-serif;font-weight:700;font-size:22px;color:var(--navy);min-height:52px"></label>' +
      '<div class="hint-banner" id="size-hint">' + esc(sizeHint) + '</div>' +
      '<div><div class="section-label">' + esc(l.presetPackages) + '</div><div class="chip-grid2">' +
        kwList.map(function (k) {
          return '<button class="' + chipClass(c.kw === k, "tall") + '" data-act="kw" data-val="' + k + '"><span class="big">' + k + ' kW</span><span class="small">₹' + inr(state.settings.rates[k]) + '/kW</span></button>';
        }).join("") +
      '</div></div>' +
      '<label class="field"><span>' + esc(l.moduleBrand) + '</span><select data-bind="panel">' + panelBrands.map(function (p) { return '<option ' + (f.panel === p ? "selected" : "") + '>' + esc(p) + '</option>'; }).join("") + '</select></label>' +
      '<label class="field"><span>' + esc(l.inverter) + '</span><select data-bind="inverter">' + inverterBrands.map(function (i) { return '<option ' + (f.inverter === i ? "selected" : "") + '>' + esc(i) + '</option>'; }).join("") + '</select></label>' +
      '<div class="card card-body" id="auto-calc">' +
        '<div class="section-label" style="margin:0">' + esc(l.autoCalc) + '</div>' +
        '<div class="kv"><span>' + esc(l.modules) + '</span><strong>' + c.panelQty + ' × ' + c.panelWattage + 'W</strong></div>' +
        '<div class="kv"><span>' + esc(l.roofArea) + '</span><strong>' + inr(c.roofArea) + ' sq ft</strong></div>' +
        '<div class="kv"><span>' + esc(l.annualGen) + '</span><strong>' + inr(c.annualUnits) + ' units</strong></div>' +
      '</div>';
  }

  function renderStep3() {
    var l = L(), f = state.form, c = calc();
    var subsidyHeading = c.residential ? (state.lang === "hi" ? "PM सूर्य घर · घरेलू" : "PM SURYA GHAR · RESIDENTIAL") : (state.lang === "hi" ? "व्यावसायिक · टैक्स लाभ" : "COMMERCIAL · TAX BENEFIT ROUTE");
    var subsidyLabel = c.residential ? (state.lang === "hi" ? "सरकारी सब्सिडी (ऑटो स्लैब)" : "Govt. subsidy (auto slab)") : (state.lang === "hi" ? "सब्सिडी (लागू नहीं)" : "Subsidy (not applicable)");
    var subsidyNote = c.residential
      ? (state.lang === "hi" ? "साइज़ के आधार पर स्लैब खुद चुना गया। कमीशनिंग के बाद ग्राहक के खाते में — हम फाइल व फॉलो-अप करते हैं।" : "Slab picked automatically from system size. Credited to the customer's bank account after commissioning — we file and follow up.")
      : (state.lang === "hi" ? "व्यावसायिक कनेक्शन में त्वरित मूल्यह्रास व GST क्रेडिट मिलता है; प्रस्ताव में ये आंकड़े दिखेंगे।" : "Commercial connections claim accelerated depreciation and input GST credit instead; the proposal shows those figures.");
    var emiOpts = [3, 5, 7, 10].map(function (y) { return { y: y, v: c["emi" + y] }; });
    return '<div class="progress"><span class="on"></span><span class="on"></span><span class="on"></span></div>' +
      '<div><div class="step-kicker">' + esc(l.stepOf3) + '</div><div class="step-title">' + esc(l.stepSub3) + '</div></div>' +
      '<div class="card">' +
        '<div class="card-header">' + esc(subsidyHeading) + '</div>' +
        '<div class="card-body">' +
          '<div class="kv"><span>' + esc(l.system) + ' + GST</span><strong>₹' + inr(c.totalPayable) + '</strong></div>' +
          '<div class="kv"><span>' + esc(subsidyLabel) + '</span><strong style="color:var(--green)">− ₹' + inr(c.subsidy) + '</strong></div>' +
          '<div class="kv divider-top"><span>' + esc(l.netCost) + '</span><strong>₹' + inr(c.netCost) + '</strong></div>' +
          '<div class="note">' + esc(subsidyNote) + '</div>' +
        '</div>' +
      '</div>' +
      '<div><div class="section-label">' + esc(l.emiHighlight) + '</div><div class="chip-grid4">' +
        emiOpts.map(function (o) {
          return '<button class="' + chipClass(f.emiYears === o.y, "tall emi-chip") + '" data-act="emi" data-val="' + o.y + '"><span class="big">' + o.y + ' yr</span><span class="small">₹' + inr(o.v) + '/mo</span></button>';
        }).join("") +
      '</div></div>' +
      '<div class="row2">' +
        '<label class="field"><span>' + esc(l.validDays) + '</span><input data-bind="validDays" inputmode="numeric" value="' + esc(f.validDays) + '"></label>' +
        '<label class="field"><span>' + esc(l.pm) + '</span><input data-bind="pm" value="' + esc(f.pm) + '"></label>' +
      '</div>' +
      '<div class="card card-body">' +
        '<div class="section-label" style="margin:0">' + esc(l.whatCustomerSees) + '</div>' +
        '<div class="kv"><span>' + esc(l.monthlySavings) + '</span><strong>₹' + inr(c.monthlySavings) + '</strong></div>' +
        '<div class="kv"><span>' + esc(l.payback) + '</span><strong>' + c.payback.toFixed(1) + ' years</strong></div>' +
        '<div class="kv"><span>' + esc(l.lifetimeSavings) + '</span><strong style="color:var(--green)">₹' + inr(c.lifetime) + '</strong></div>' +
      '</div>';
  }

  function renderReview() {
    var l = L(), f = state.form, c = calc();
    var editing = state.editingId ? state.quotes.find(function (q) { return q.id === state.editingId; }) : null;
    var reviewName = f.name.trim() || (state.lang === "hi" ? "नया ग्राहक" : "New customer");
    var quoteNoDisplay = editing ? editing.quoteNo : l.quotationPending;
    var lastBtnAct = editing ? "save-changes" : "save-draft";
    var lastBtnLabel = editing ? l.saveChanges : l.saveDraft;
    return (state.saveError ? '<div class="error-bar">' + esc(state.saveError) + '</div>' : '') +
      '<div class="summary-card">' +
      '<div class="kicker">' + esc(l.quotationLabel) + ' ' + esc(quoteNoDisplay) + '</div>' +
      '<div class="name">' + esc(reviewName) + '</div>' +
      '<div class="meta">' + c.kw + ' kW · ' + esc(f.panel) + ' · valid till ' + esc(c.validUntil) + '</div>' +
      '<div class="summary-grid">' +
        '<div><div class="lbl">' + esc(l.netInvestment) + '</div><div class="val">₹' + inr(c.netCost) + '</div></div>' +
        '<div><div class="lbl">' + esc(l.savesPerMonth) + '</div><div class="val">₹' + inr(c.monthlySavings) + '</div></div>' +
      '</div>' +
    '</div>' +
    '<div><div class="section-label">' + esc(l.proposalReady) + '</div><div class="thumbs">' +
      l.pageThumbs.map(function (label, i) {
        return '<div class="thumb"><div class="bar"></div><div class="body"><div class="label">' + esc(label) + '</div><div class="no">0' + (i + 1) + '</div></div></div>';
      }).join("") +
    '</div></div>' +
    '<button class="btn-outline" data-act="preview">' + esc(l.previewProposal) + '</button>' +
    '<button class="btn-green" data-act="whatsapp">' + esc(l.sendWhatsapp) + '</button>' +
    '<button class="btn-navy" data-act="download">' + esc(l.downloadPdf) + '</button>' +
    '<button class="btn-ghost" data-act="' + lastBtnAct + '">' + esc(lastBtnLabel) + '</button>' +
    '<div class="note">' + esc(l.sendingNote) + '</div>';
  }

  function renderDetail() {
    var l = L();
    var d = state.quotes.find(function (q) { return q.id === state.detailId; }) || state.quotes[0];
    if (!d) return '<div class="empty-state">' + esc(l.noQuotes) + '</div>';
    var statuses = [["Sent", l.statusSent], ["Won", l.statusWon], ["Lost", l.statusLost]];
    var followUp = l.followUpWord.replace("{n}", d.name);
    var deleteBlock;
    if (state.confirmDeleteId === d.id) {
      deleteBlock = '<div class="confirm-box"><div class="note">' + esc(l.confirmDelete) + '</div>' +
        '<div class="confirm-row"><button class="btn-outline" data-act="cancel-delete">' + esc(l.cancel) + '</button>' +
        '<button class="btn-danger solid" data-act="confirm-delete" data-id="' + d.id + '">' + esc(l.yesDelete) + '</button></div></div>';
    } else {
      deleteBlock = '<button class="btn-danger" data-act="delete-quote" data-id="' + d.id + '">' + esc(l.deleteQuotation) + '</button>';
    }
    return '<div class="detail-card">' +
      '<div class="detail-head"><div style="min-width:0"><div class="name">' + esc(d.name) + '</div><div class="meta">' + esc(d.place) + ' · ' + esc(d.phone) + '</div></div>' +
        '<span class="qc-side">' +
          '<span class="pill" style="background:' + (STATUS_COLORS[d.status] || "#6B7A88") + '">' + esc(d.status) + '</span>' +
          (d.synced === false ? '<span class="badge-unsynced">' + esc(l.notSynced) + '</span>' : '') +
        '</span></div>' +
      '<div class="detail-grid">' +
        '<div><div class="lbl">' + esc(l.system) + '</div><strong>' + d.kw + ' kW</strong></div>' +
        '<div><div class="lbl">' + esc(l.quoteNo) + '</div><strong>' + esc(d.quoteNo) + '</strong></div>' +
        '<div><div class="lbl">' + esc(l.netCost) + '</div><strong>₹' + inr(d.net) + '</strong></div>' +
        '<div><div class="lbl">' + esc(l.savesMonth) + '</div><strong>₹' + inr(d.monthly) + '</strong></div>' +
      '</div>' +
    '</div>' +
    '<div><div class="section-label">' + esc(l.updateStatus) + '</div><div class="chip-row">' +
      statuses.map(function (s) { return '<button class="' + chipClass(d.status === s[0]) + '" data-act="status" data-id="' + d.id + '" data-val="' + s[0] + '">' + esc(s[1]) + '</button>'; }).join("") +
    '</div></div>' +
    '<button class="btn-green" data-act="resend-detail" data-id="' + d.id + '">' + esc(l.resendWhatsapp) + '</button>' +
    '<button class="btn-outline" data-act="open-detail-proposal" data-id="' + d.id + '">' + esc(l.openProposal) + '</button>' +
    '<button class="btn-outline" data-act="edit-quote" data-id="' + d.id + '">' + esc(l.editQuotation) + '</button>' +
    deleteBlock +
    '<div class="note">' + esc(followUp) + '</div>';
  }

  function renderSettings() {
    var l = L(), st = state.settings;
    var kwList = [2, 3, 5, 10];
    var assumptions = [
      { key: "gstPercent", label: l.gst, hint: l.gstHint },
      { key: "tariff", label: l.tariff, hint: l.tariffHint },
      { key: "unitsPerKw", label: l.generation, hint: l.generationHint },
      { key: "emiRate", label: l.emiRate, hint: l.emiRateHint },
      { key: "subsidyCap", label: l.subsidyCap, hint: l.subsidyCapHint }
    ];
    var companyFields = [
      { key: "gstin", label: l.gstinLabel },
      { key: "serviceNumber", label: l.serviceNumberLabel },
      { key: "bankName", label: l.bankNameLabel },
      { key: "accountNo", label: l.accountNoLabel }
    ];
    return '<div class="settings-intro">' + esc(l.settingsIntro) + '</div>' +
      '<div class="card">' +
        '<div class="card-header" style="border-bottom:1px solid #E7EEF2">' + esc(l.packageRates) + '</div>' +
        kwList.map(function (k) {
          return '<div class="settings-row"><span class="lbl">' + k + ' kW ' + esc(l.kwPackageWord) + '</span><input data-setting-rate="' + k + '" inputmode="numeric" value="' + st.rates[k] + '"></div>';
        }).join("") +
      '</div>' +
      '<div class="card">' +
        '<div class="card-header" style="border-bottom:1px solid #E7EEF2">' + esc(l.assumptionsSlabs) + '</div>' +
        assumptions.map(function (a) {
          return '<div class="settings-row"><span class="lbl"><span style="display:block">' + esc(a.label) + '</span><span class="hint">' + esc(a.hint) + '</span></span><input data-setting="' + a.key + '" inputmode="numeric" value="' + esc(st[a.key]) + '"></div>';
        }).join("") +
      '</div>' +
      '<div class="card">' +
        '<div class="card-header" style="border-bottom:1px solid #E7EEF2">' + esc(l.companyDetails) + '</div>' +
        companyFields.map(function (a) {
          return '<div class="settings-row"><span class="lbl">' + esc(a.label) + '</span><input data-setting="' + a.key + '" value="' + esc(st[a.key]) + '" style="width:170px;text-align:left"></div>';
        }).join("") +
      '</div>';
  }

  function renderLiveBar() {
    var l = L(), c = calc();
    var nextLabel = state.screen === "step3" ? (state.lang === "hi" ? "बनाएं" : "Generate") : (state.lang === "hi" ? "आगे" : "Next");
    return '<div class="live-bar" id="live-bar">' +
      '<div style="flex:1;min-width:0"><div class="lbl">' + esc(l.netInvestment) + ' · ' + esc(l.savesPerMonth) + '</div>' +
      '<div class="val">₹<span id="live-net">' + inr(c.netCost) + '</span> <span class="save">· ₹<span id="live-save">' + inr(c.monthlySavings) + '</span></span></div></div>' +
      '<button data-act="next">' + esc(nextLabel) + '</button>' +
    '</div>';
  }

  function renderTabBar() {
    var l = L();
    var tabs = [["quotes", l.tabQuotes, "list"], ["new", l.tabNew, "step1"], ["settings", l.tabSettings, "settings"]];
    return '<div class="tab-bar">' + tabs.map(function (t) {
      return '<button class="' + (state.tab === t[0] ? "active" : "") + '" data-act="tab" data-tab="' + t[0] + '" data-screen="' + t[2] + '">' + esc(t[1]) + '</button>';
    }).join("") + '</div>';
  }

  function render() {
    var body;
    switch (state.screen) {
      case "step1": body = renderStep1(); break;
      case "step2": body = renderStep2(); break;
      case "step3": body = renderStep3(); break;
      case "review": body = renderReview(); break;
      case "detail": body = renderDetail(); break;
      case "settings": body = renderSettings(); break;
      default: body = renderList();
    }
    var showLiveBar = state.screen === "step1" || state.screen === "step2" || state.screen === "step3";
    var html =
      '<div class="page-wrap">' +
        '<div class="intro">' +
          '<div class="kicker">SHUBH SOLAR · INTERNAL TOOL</div>' +
          '<h1>Quotation builder</h1>' +
          '<div class="hi">डिटेल भरो, कोटेशन तैयार।</div>' +
          '<p>A phone web app for Akhilesh and the field team. Enter the customer, their bill and the system size — prices, subsidy, savings and EMI come from saved presets, and the 6-page proposal is generated ready to send on WhatsApp. Now with an English / Hindi toggle so any team member can work in the language they\'re comfortable with.</p>' +
          '<div class="tips">' +
            '<div><strong style="color:var(--navy)">Try it:</strong> tap <em>New quotation</em>, fill three short steps, and watch the net cost update live at the bottom.</div>' +
            '<div>Everything typed here is saved on the phone, so a half-finished quote survives a lost signal at site.</div>' +
          '</div>' +
        '</div>' +
        '<div class="phone-shell">' +
          '<div class="notch"></div>' +
          '<div class="phone">' +
            renderShellHeader() +
            '<div class="phone-body">' + body + '</div>' +
            (showLiveBar ? renderLiveBar() : '') +
            (state.toast ? '<div class="toast">' + esc(state.toast) + '</div>' : '') +
            renderTabBar() +
          '</div>' +
          '<div class="home-indicator"></div>' +
        '</div>' +
      '</div>';
    document.getElementById("app").innerHTML = html;
    bindTextInputs();
  }

  // Text/number inputs update state directly on 'input' (no full re-render — keeps focus/caret).
  function bindTextInputs() {
    var root = document.getElementById("app");
    root.querySelectorAll("[data-bind]").forEach(function (el) {
      el.addEventListener("input", function () {
        setForm(el.getAttribute("data-bind"), el.value);
        if (el.getAttribute("data-bind") === "bill") patchLiveNumbers();
      });
      el.addEventListener("change", function () {
        if (el.tagName === "SELECT") { setForm(el.getAttribute("data-bind"), el.value); render(); }
      });
    });
    root.querySelectorAll("[data-setting]").forEach(function (el) {
      el.addEventListener("change", function () { setSetting(el.getAttribute("data-setting"), el.value); patchLiveNumbers(); });
    });
    root.querySelectorAll("[data-setting-rate]").forEach(function (el) {
      el.addEventListener("change", function () { setRate(el.getAttribute("data-setting-rate"), num(el.value)); });
    });
  }

  // Patches the few live-dependent numbers on step2/step3 without a full re-render (avoids losing input focus while typing bill).
  function patchLiveNumbers() {
    var c = calc();
    var liveNet = document.getElementById("live-net"), liveSave = document.getElementById("live-save");
    if (liveNet) liveNet.textContent = inr(c.netCost);
    if (liveSave) liveSave.textContent = inr(c.monthlySavings);
    var hint = document.getElementById("size-hint");
    if (hint && state.screen === "step2") {
      var bill = num(state.form.bill), suggested = Math.max(1, Math.round(bill / 1000));
      hint.textContent = bill > 0
        ? (state.lang === "hi" ? "₹" + inr(bill) + " बिल के लिए सामान्यतः " + suggested + " kW चाहिए। Adani 550W मॉड्यूल, साल में " + inr(c.annualUnits) + " यूनिट।" : "A ₹" + inr(bill) + " bill usually needs about " + suggested + " kW. Adani 550W modules, " + inr(c.annualUnits) + " units a year.")
        : (state.lang === "hi" ? "औसत बिल डालें, ऐप साइज़ सुझाएगा।" : "Enter the average bill and the app suggests a size.");
    }
    var autoCalc = document.getElementById("auto-calc");
    if (autoCalc && state.screen === "step2") render(); // kw-dependent numbers need the fuller refresh, but caret only lives in the bill field which patches above first
  }

  // Click delegation for all buttons.
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-act]");
    if (!el) return;
    var act = el.getAttribute("data-act");
    switch (act) {
      case "lang": state.lang = el.getAttribute("data-val"); persist(); render(); break;
      case "back": back(); break;
      case "filter": state.filter = el.getAttribute("data-val"); render(); break;
      case "open-detail": state.screen = "detail"; state.detailId = el.getAttribute("data-id"); state.confirmDeleteId = null; render(); break;
      case "new-quotation": state.editingId = null; state.form = Object.assign({}, DEFAULT_FORM); goStep(1); break;
      case "category": setForm("category", el.getAttribute("data-val")); render(); break;
      case "kw": setForm("kw", Number(el.getAttribute("data-val"))); render(); break;
      case "emi": setForm("emiYears", Number(el.getAttribute("data-val"))); render(); break;
      case "next": next(); break;
      case "tab":
        state.tab = el.getAttribute("data-tab"); state.screen = el.getAttribute("data-screen"); state.detailId = null;
        if (state.tab === "new") { state.editingId = null; state.form = Object.assign({}, DEFAULT_FORM); }
        render();
        break;
      case "preview": commitQuote("Draft").then(function (q) { publishQuote(q); openProposal(q.token); }); break;
      case "whatsapp": commitQuote("Sent").then(function (q) { publishQuote(q); openWhatsApp(q); flash("WhatsApp opened for " + q.name); }); break;
      case "download": commitQuote("Draft").then(function (q) { publishQuote(q); openProposal(q.token); }); break;
      case "save-draft": commitQuote("Draft").then(function (q) { state.screen = "list"; state.tab = "quotes"; render(); flash(q.synced ? "Saved to customer list" : "Saved on this device — could not reach the server"); }); break;
      case "save-changes": (function () {
        var existing = state.editingId ? state.quotes.find(function (q) { return q.id === state.editingId; }) : null;
        var status = existing ? existing.status : "Draft";
        commitQuote(status).then(function (q) { state.screen = "list"; state.tab = "quotes"; render(); flash(q.synced ? "Changes saved" : "Saved on this device — could not reach the server"); });
      })(); break;
      case "status":
        state.quotes = state.quotes.map(function (q) { return q.id === el.getAttribute("data-id") ? Object.assign({}, q, { status: el.getAttribute("data-val") }) : q; });
        persist(); render();
        if (apiAvailable) {
          var qNow = state.quotes.find(function (q) { return q.id === el.getAttribute("data-id"); });
          if (qNow && qNow.synced) {
            fetch(API_BASE + "quotations.php?id=" + encodeURIComponent(el.getAttribute("data-id")), {
              method: "PATCH", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ status: el.getAttribute("data-val") })
            }).then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
              .then(function (res) { if (!res.ok || !res.body || !res.body.success) flash("Could not sync status to the server."); })
              .catch(function () { flash("Could not sync status to the server."); });
          }
        }
        break;
      case "resend-detail": (function () { var d = state.quotes.find(function (q) { return q.id === el.getAttribute("data-id"); }); if (!d) return; publishQuote(d); openWhatsApp(d); flash("WhatsApp opened for " + d.name); })(); break;
      case "open-detail-proposal": (function () { var d = state.quotes.find(function (q) { return q.id === el.getAttribute("data-id"); }); if (!d) return; publishQuote(d); openProposal(d.token); })(); break;
      case "edit-quote": (function () { var d = state.quotes.find(function (q) { return q.id === el.getAttribute("data-id"); }); if (d) startEdit(d); })(); break;
      case "delete-quote": state.confirmDeleteId = el.getAttribute("data-id"); render(); break;
      case "cancel-delete": state.confirmDeleteId = null; render(); break;
      case "confirm-delete": deleteQuote(el.getAttribute("data-id")); break;
    }
  });

  restore();
  render();
})();
